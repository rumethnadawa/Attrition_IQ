from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import LabelEncoder
import os

app = FastAPI(title="HR Attrition Prediction API")

# Mount static files for UI and Outputs
os.makedirs("static", exist_ok=True)
os.makedirs("outputs", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")

# Load model and feature names
MODEL_DIR = "models"
DATA_PATH = "WA_Fn-UseC_-HR-Employee-Attrition.csv"

model = joblib.load(f"{MODEL_DIR}/best_model.pkl")
feature_names = joblib.load(f"{MODEL_DIR}/feature_names.pkl")

# Re-create Label Encoders (same logic as analysis_pipeline.py)
df = pd.read_csv(DATA_PATH)
DROP_COLS = ['EmployeeCount', 'EmployeeNumber', 'Over18', 'StandardHours']
df.drop(columns=DROP_COLS, inplace=True, errors='ignore')
cat_cols = df.drop(columns=['Attrition'], errors='ignore').select_dtypes(include='object').columns.tolist()

encoders = {}
for col in cat_cols:
    le = LabelEncoder()
    le.fit(df[col])
    encoders[col] = le

class EmployeeData(BaseModel):
    Age: int
    BusinessTravel: str
    DailyRate: int
    Department: str
    DistanceFromHome: int
    Education: int
    EducationField: str
    EnvironmentSatisfaction: int
    Gender: str
    HourlyRate: int
    JobInvolvement: int
    JobLevel: int
    JobRole: str
    JobSatisfaction: int
    MaritalStatus: str
    MonthlyIncome: int
    MonthlyRate: int
    NumCompaniesWorked: int
    OverTime: str
    PercentSalaryHike: int
    PerformanceRating: int
    RelationshipSatisfaction: int
    StockOptionLevel: int
    TotalWorkingYears: int
    TrainingTimesLastYear: int
    WorkLifeBalance: int
    YearsAtCompany: int
    YearsInCurrentRole: int
    YearsSinceLastPromotion: int
    YearsWithCurrManager: int

@app.get("/")
def read_root():
    return FileResponse("static/index.html")

@app.post("/predict")
def predict(data: EmployeeData):
    try:
        # Convert input to DataFrame
        # Compatibility for both pydantic v1 and v2
        data_dict = data.model_dump() if hasattr(data, 'model_dump') else data.dict()
        input_data = pd.DataFrame([data_dict])
        
        # Encode categorical columns
        for col in cat_cols:
            if col in input_data.columns:
                # Handle unseen labels by falling back to the first class if needed
                # (Assuming UI constraints will prevent unseen labels)
                input_data[col] = encoders[col].transform(input_data[col])
                
        # Ensure correct feature order as expected by the model
        input_df = input_data[feature_names]
        
        # Random Forest in the pipeline was trained on unscaled data (X_train_sm)
        # We only scale if the model is LR or SVM.
        is_tree_based = any(tree in str(type(model)) for tree in ["RandomForest", "GradientBoosting", "DecisionTree"])
        
        if not is_tree_based:
            scaler = joblib.load(f"{MODEL_DIR}/scaler.pkl")
            X = scaler.transform(input_df)
        else:
            X = input_df
            
        prediction = model.predict(X)[0]
        probability = model.predict_proba(X)[0][1] # Probability of "Leave" (class 1)
        
        return {
            "prediction": "Leave" if prediction == 1 else "Stay",
            "leave_probability": float(probability),
            "stay_probability": 1.0 - float(probability)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
